///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Sep 24 2018)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __LMS7002_WXGUI_H__
#define __LMS7002_WXGUI_H__

#include <wx/artprov.h>
#include <wx/xrc/xmlres.h>
class NumericSlider;
class lms7002_pnlAFE_view;
class lms7002_pnlBIAS_view;
class lms7002_pnlBIST_view;
class lms7002_pnlCDS_view;
class lms7002_pnlCLKGEN_view;
class lms7002_pnlCalibrations_view;
class lms7002_pnlGains_view;
class lms7002_pnlLDO_view;
class lms7002_pnlLimeLightPAD_view;
class lms7002_pnlRBB_view;
class lms7002_pnlRFE_view;
class lms7002_pnlRxTSP_view;
class lms7002_pnlSX_view;
class lms7002_pnlTBB_view;
class lms7002_pnlTRF_view;
class lms7002_pnlTxTSP_view;
class lms7002_pnlXBUF_view;

#include <wx/string.h>
#include <wx/button.h>
#include <wx/gdicmn.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/combobox.h>
#include <wx/radiobut.h>
#include <wx/checkbox.h>
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/panel.h>
#include <wx/bitmap.h>
#include <wx/image.h>
#include <wx/icon.h>
#include <wx/notebook.h>
#include <wx/statbox.h>
#include <wx/spinctrl.h>
#include <wx/radiobox.h>
#include <wx/textctrl.h>
#include <wx/choice.h>
#include <wx/gauge.h>
#include <wx/grid.h>
#include <wx/dialog.h>

#endif //__LMS7002_WXGUI_H__
