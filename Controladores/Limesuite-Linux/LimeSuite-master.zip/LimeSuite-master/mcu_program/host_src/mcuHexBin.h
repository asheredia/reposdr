#ifndef LMS7002M_MCU_HEX_2_BIN_H
#define LMS7002M_MCU_HEX_2_BIN_H

#include <stdint.h>

int MCU_HEX2BIN(const char* filename, uint16_t limit, uint8_t *binImage, uint16_t *imageSize);

#endif // LMS7002M_MCU_HEX_2_BIN_H
